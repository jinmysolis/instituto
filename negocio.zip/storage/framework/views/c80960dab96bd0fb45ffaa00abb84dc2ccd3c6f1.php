<?php $__env->startSection('content'); ?>
<div class="boy">
 
        <div id="contac"class="col-md-6">
                     
                        
                         <img src="img/registro.png" >
                         
                       
        </div>
            
    
     <div id="contac2" class="col-md-6">
         
          <img src="img/flacha.png" >
          <h1 class="text-right">Registro</h1>
          <h5 class="text-right">Ya Tienes cuenta <a href="#">Inicia Ahora</a></h5>
         
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <br> <br> 
                        
                        <div class="text-right"> <label for="name" class="text-center">NOMBRE</label></div>
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            
                            <div class="col-md-12">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                        <div class="text-right"> <label for="apellidos" >APELLIDO</label></div>
                        <div class="form-group<?php echo e($errors->has('apellidos') ? ' has-error' : ''); ?>">
                           <div class="col-md-12">
                                <input id="apellidos" type="text" class="form-control" name="apellidos" value="<?php echo e(old('apellidos')); ?>" required autofocus>

                                <?php if($errors->has('apellidos')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('apellidos')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                         <div class="text-right"><label for="email" >USUARIO O CORREO ELECTRONICO</label></div>
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                             <div class="col-md-12">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                            
                          <div class="text-right"><label for="email-confirm" >CONFIRMAR USUARIO O CORREO ELECTRONICO</label>  </div>
                        <div class="form-group">
                            <div class="col-md-12">
                                <input id="email-confirm" type="email" class="form-control" name="email_confirmation" required>
                            </div>
                        </div>
                            
                          <div class="text-right"> <label for="password" >CONTRASEÑA</label></div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                         <div class="col-md-12">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                
                            
                            <div class="text-right"><label for="pais" >PAIS</label></div>
                        <div class="form-group<?php echo e($errors->has('pais') ? ' has-error' : ''); ?>">
                           
                            <div class="col-md-12">
                                <input id="pais" type="text" class="form-control" name="pais" value="<?php echo e(old('pais')); ?>" required autofocus>

                                <?php if($errors->has('pais')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('pais')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                            
                            
                            
                            
                            
                             <div class="text-right"><?php echo Form::label('tipoCuenta', 'TIPO DE CUENTA'); ?></div>
                            
                            
                                 <div id="empresa-personal"class="text-center">
                                     <img src="img/registro-empresa.png">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                     <img src="img/registro-persona.png">
                                <br>
                            <label class="radio-inline"><input type="radio" name="tipoCuenta" value="empresa" id="tipoCuenta">Empresa</label>
                            <label class="radio-inline"><input type="radio" name="tipoCuenta" value="personal" id="tipoCuenta">Personal</label>
                            
                            </div>
                            
                            
                       
                             <div id="reg">  
                        <div class="form-group text-center">
                            <div class="col-md-6 ">
                                <button type="submit" class="btn btn-success">
                                    Register
                                </button>
                            </div>
                            
                        </div>
                                 </div> 
                              <br>
                         

                    </form>
        </div>
    </div>            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>